////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//     This software is supplied under the terms of a license agreement or    //
//     nondisclosure agreement with Mitov Software and may not be copied      //
//     or disclosed except in accordance with the terms of that agreement.    //
//         Copyright(c) 2002-2017 Mitov Software. All Rights Reserved.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef _MITOV_DISPLAY_SSD1306_I2C_h
#define _MITOV_DISPLAY_SSD1306_I2C_h

#include <Mitov_Display_SSD1306.h>

namespace Mitov
{
//---------------------------------------------------------------------------
//	template<ArduinoDisplayOLEDType T_PARAM> typedef DisplaySSD1306	DisplaySSD1306I2C<T_PARAM>;
/*
	class DisplaySSD1306I2C : public DisplaySSD1306
	{
		typedef DisplaySSD1306 inherited;

	public:
		uint8_t	Address = 0x3C;

	protected:
		virtual void SendCommand( uint8_t ACommand ) override
		{
//			Serial.println( ACommand, HEX );
			Wire.beginTransmission( Address );
			Wire.write( 0x00 ); // Co = 0, D/C = 0
			Wire.write( ACommand );
			Wire.endTransmission();
		}

		virtual void SendBuffer() override
		{
			// I2C
			for( uint16_t i=0; i < ( FWidth * FHeight /8); ) 
			{
				// send a bunch of data in one xmission
				Wire.beginTransmission( Address );
				Wire.write( 0x40 );
				Wire.write( buffer + i, 16 );
				i += 16;
				Wire.endTransmission();
			}
		}

	public:
		using inherited::inherited;

	};
*/
//---------------------------------------------------------------------------
}

#endif
