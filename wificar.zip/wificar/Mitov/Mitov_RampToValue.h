////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//     This software is supplied under the terms of a license agreement or    //
//     nondisclosure agreement with Mitov Software and may not be copied      //
//     or disclosed except in accordance with the terms of that agreement.    //
//         Copyright(c) 2002-2017 Mitov Software. All Rights Reserved.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef _MITOV_RAMP_TO_VALUE_h
#define _MITOV_RAMP_TO_VALUE_h

#include <Mitov.h>

namespace Mitov
{
	class RampToValue : public OpenWire::Component, public Mitov::ClockingSupport
	{
		typedef OpenWire::Component inherited;

	public:
		OpenWire::SinkPin	InputPin;
		OpenWire::SourcePin	OutputPin;

    public:
        bool	Enabled = true;
		float	InitialValue = 0.0f;
		float	Slope = 1.0f;

	public:
		void SetInitialValue( float AValue )
		{
			InitialValue = AValue;
			FCurrentValue = InitialValue;
		}

	protected:
		unsigned long	FLastTime = 0;
		float			FCurrentValue = 0.0f;
		float			FTargetValue = 0.0f;

	protected:
		void DoReceive( void *_Data )
		{
			float AValue = *(float *)_Data;
			FTargetValue = AValue;
		}

		virtual void DoClockReceive( void *_Data ) override
		{
			Generate( micros(), true );
		}

		void Generate( unsigned long currentMicros, bool FromClock )
		{
			if( FCurrentValue != FTargetValue )
			{
				if( ! Enabled )
					FCurrentValue = FTargetValue;

				else
				{
					float ARamp = abs( ( currentMicros - FLastTime ) * Slope / 1000000 );
					if( FCurrentValue < FTargetValue )
					{
						FCurrentValue += ARamp;
						if( FCurrentValue > FTargetValue )
							FCurrentValue = FTargetValue;

					}
					else
					{
						FCurrentValue -= ARamp;
						if( FCurrentValue < FTargetValue )
							FCurrentValue = FTargetValue;

					}
				}

				OutputPin.Notify( &FCurrentValue );
			}

			else if( FromClock )
				OutputPin.Notify( &FCurrentValue );

			FLastTime = currentMicros;
//			inherited::SendOutput();
		}

	protected:
		virtual void SystemStart() override
		{
			FCurrentValue = InitialValue;
			FTargetValue = InitialValue;

			OutputPin.Notify( &FCurrentValue );
//			inherited::SystemStart();
		}

		virtual void SystemLoopBegin( unsigned long currentMicros ) override
		{
			if( ! ClockInputPin.IsConnected() )
				Generate( currentMicros, false );

//			inherited::SystemLoopBegin( currentMicros );
		}

	public:
		RampToValue()
		{
			InputPin.SetCallback( MAKE_CALLBACK( RampToValue::DoReceive ));
		}
	};
}

#endif
