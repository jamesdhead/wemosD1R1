////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//     This software is supplied under the terms of a license agreement or    //
//     nondisclosure agreement with Mitov Software and may not be copied      //
//     or disclosed except in accordance with the terms of that agreement.    //
//         Copyright(c) 2002-2017 Mitov Software. All Rights Reserved.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#ifndef _MITOV_ANALOGARRAY_h
#define _MITOV_ANALOGARRAY_h

#include <Mitov.h>

namespace Mitov
{
	class SlidingWindowAnalogArray : public CommonFilter, public ClockingSupport
	{
		typedef CommonFilter inherited;

	public:
		uint16_t	Count = 128;
		uint16_t	Step = 1;
		bool		Normalize = false;

	protected:
		float		*FQueue = nullptr;
		uint16_t	FIndex = 0;
		uint16_t	FStepCounter = 0;

	public:
		void SetCount( uint16_t AValue )
		{
			if( Count == AValue )
				return;

			float	*AOldBuffer = FQueue;
			FQueue = new float[ AValue ];

			if( AValue > Count )
				memset( FQueue + Count, 0, ( AValue - Count ) * sizeof( float ) );

			memcpy( FQueue, AOldBuffer, MitovMin( Count, AValue ) * sizeof( float ));

			Count = AValue;
			delete [] AOldBuffer;
		}

	protected:
		virtual void DoReceive( void *_Data ) override
		{
			if( FIndex >= Count )
				FIndex = 0;

			FQueue[ FIndex ++ ] = *(float *)_Data;
			if( ClockInputPin.IsConnected() )
				return;

			uint16_t AStep = ( Step ) ? Step : Count;
			if( ++ FStepCounter >= AStep )
			{
				FStepCounter = 0;
				DoClockReceive( nullptr );
			}
		}

		virtual void DoClockReceive( void *_Data ) override
		{
			float *AData = new float[ Count ];

			float *APtr = AData;
			int AIndex = FIndex;

			if( Normalize )
			{
				float AMin = FQueue[ 0 ]; //MitovMin
				float AMax = AMin; //MitovMax

				for( int i = 1; i < Count; ++i )
				{
					AMin = MitovMin( AMin, FQueue[ i ] );
					AMax = MitovMax( AMax, FQueue[ i ] );
				}

				for( uint16_t i = 0; i < Count; ++i )
				{
					if( AIndex >= Count )
						AIndex = 0;

					*APtr++ = (( FQueue[ AIndex ++ ] - AMin ) / ( AMax - AMin ));
				}
			}

			else
			{
				for( uint16_t i = 0; i < Count; ++i )
				{
					if( AIndex >= Count )
						AIndex = 0;

					*APtr++ = FQueue[ AIndex ++ ];
				}
			}

			TArray<float> ABuffer( Count, AData );
			inherited::OutputPin.Notify( &ABuffer );

			delete [] AData;
		}

	protected:
		virtual void SystemInit() override
		{
			if( FQueue )
				delete [] FQueue;

			FQueue = new float[ Count ];
//			inherited::SystemInit();
		}

	};
}

#endif
