#Component Development Libraries#
##For Visuino the Arduino Visual Programming Environment##
##by Mitov Software##

###What these files are###
**These are the the Visuino Component Libraries, these libraries are used by the Visuino generated code**

They are updated when a new version of Visuino is released and are Open Source.

These Libraries can be used to see what has changed in some of the core code used to build Visuino.




###What these files are not###

They are not a way to build your own version of Visuino.

They are not an SDK.  The SDK is a separate release that is shared with the Google Plus Visuino DEV Community, which can be found here: (https://plus.google.com/communities/116125623808250792822)

They are not a free version of Visuino.  You can get a trial version here: (https://www.visuino.com/download)